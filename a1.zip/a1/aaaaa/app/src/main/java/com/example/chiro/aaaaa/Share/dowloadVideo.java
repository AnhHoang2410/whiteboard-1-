package com.example.chiro.aaaaa.Share;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;

import java.io.File;

public class dowloadVideo {
/** can use this code to dowload a video from firebase
 *
 * check this link to play svg file on Android
 * https://stackoverflow.com/questions/9115696/android-and-playing-svg-animation
 *
    File localFile = File.createTempFile("images", "jpg");
riversRef.getFile(localFile)
            .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
        @Override
        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
            // Successfully downloaded data to local file
            // ...
        }
    }).addOnFailureListener(new OnFailureListener() {
        @Override
        public void onFailure(@NonNull Exception exception) {
            // Handle failed download
            // ...
        }
    });
 */
}
